#!/bin/bash

if [[ -z "$1" ]]; then
  echo " give version "
  echo " 1.16, 1.17"
  exit 0
fi

if [[ "$1" != "1.16" && "$1" != "1.17" ]]; then
  echo "invalid version"
  echo " 1.16, 1.17"
  exit 0
fi

hosts_m="master1 master2 master3"
join_hosts_m="master2 master3"
hosts_w="worker1 worker2"
join_hosts_w="worker1 worker2"

if [ "$1" == "1.16" ]; then
  for host in $hosts_m; do
    vagrant ssh $host -- sudo kubeadm reset -f || true
  done
  vagrant ssh worker1 -- sudo kubeadm reset -f || true
elif [ "$1" == "1.17" ]; then
  vagrant ssh masterXX -- sudo kubeadm reset -f || true
  vagrant ssh worker2 -- sudo kubeadm reset -f || true
fi

if [ "$1" == "1.16" ]; then
# Using Kubeadm, create a cluster on master1
  LB_IP=$(vagrant ssh loadbalancer -- hostname -I | tr ' ' '\n' | grep -m2 1 | tail -n1)
  if [ -z "$LB_IP" ]; then
    echo "Loadbalancer IP not set"
    exit 0
  fi
fi

if [ "$1" == "1.16" ]; then
  # encryption key for certs
  KEY=$(openssl rand -hex 32)
  vagrant ssh master1 -- cp /vagrant/config-1.16.yaml /home/vagrant/kubeadm-config.yaml
  vagrant ssh master1 -- sed -i 's/CHANGE_ME/'"$LB_IP"'/g' /home/vagrant/kubeadm-config.yaml
  vagrant ssh master1 -- sed -i 's/CHANGE_CERT_KEY/'"$KEY"'/g' /home/vagrant/kubeadm-config.yaml

  echo "--------------------"
  echo "!!! init master1 !!!"
  echo "--------------------"
  vagrant ssh master1 -- sudo kubeadm init --upload-certs --config=/home/vagrant/kubeadm-config.yaml | tee init_results.txt

  cat init_results.txt  | grep 'To start using your cluster' -A 4 | tail -n 3 > masters_kubeconfig.sh

  # configure kubeconfig on master1
  vagrant upload masters_kubeconfig.sh master1
  vagrant ssh master1 -- chmod 700 masters_kubeconfig.sh
  vagrant ssh master1 -- ./masters_kubeconfig.sh
fi

# join
TOKEN=$(vagrant ssh master1 -- kubeadm token generate)
JOIN_WORKER=$(vagrant ssh master1 -- sudo kubeadm token create ${TOKEN} --print-join-command)

if [ "$1" == "1.16" ]; then
  JOIN_MASTER="${JOIN_WORKER} --control-plane --certificate-key ${KEY}"
elif [ "$1" == "1.17" ]; then
  #CERT_KEY=$(vagrant ssh master1 -- cat /home/vagrant/kubeadm-config.yaml | grep certificateKey | cut -d ':' -f2  | awk '{$1=$1;print}')
  # or
  vagrant ssh master1 -- sudo kubeadm init phase upload-certs --upload-certs  --config=/home/vagrant/kubeadm-config.yaml 1>cert
  CERT_KEY=$(tail -1 cert)
  JOIN_MASTER="${JOIN_WORKER} --control-plane --certificate-key ${CERT_KEY}"
fi

if [ "$1" == "1.16" ]; then
  # configure kubeconfig and run join command
  for host in $join_hosts_m;do
  echo "--------------------"
  echo "!!! join $host !!!"
  echo "--------------------"
     vagrant upload masters_kubeconfig.sh $host
     vagrant ssh $host -- chmod 700 masters_kubeconfig.sh
     vagrant ssh $host -- sudo $JOIN_MASTER
     vagrant ssh $host -- ./masters_kubeconfig.sh
  done
  for host in worker1;do
  echo "--------------------"
  echo "!!! join $host !!!"
  echo "--------------------"
     vagrant upload masters_kubeconfig.sh $host
     vagrant ssh $host -- chmod 700 masters_kubeconfig.sh
     vagrant ssh $host -- sudo $JOIN_WORKER
     vagrant ssh $host -- ./masters_kubeconfig.sh
  done
elif [ "$1" == "1.17" ]; then
  for host in masterXX;do
  echo "--------------------"
  echo "!!! join $host !!!"
  echo "--------------------"
     vagrant upload masters_kubeconfig.sh $host
     vagrant ssh $host -- chmod 700 masters_kubeconfig.sh
     vagrant ssh $host -- sudo $JOIN_MASTER
     vagrant ssh $host -- ./masters_kubeconfig.sh
  done
  for host in worker2;do
  echo "--------------------"
  echo "!!! join $host !!!"
  echo "--------------------"
     vagrant upload masters_kubeconfig.sh $host
     vagrant ssh $host -- chmod 700 masters_kubeconfig.sh
     vagrant ssh $host -- sudo $JOIN_WORKER
     vagrant ssh $host -- ./masters_kubeconfig.sh
  done
fi

if [ "$1" == "1.16" ]; then
# set up pods networking on any of the masters
# Make sure you have enabled kubectl on master1
#vagrant ssh master1 -- kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/bc79dd1505b0c8681ece4de4c0d86c5cd2643275/Documentation/kube-flannel.yml
# https://docs.projectcalico.org/v3.7/getting-started/kubernetes/
  vagrant ssh master1 -- kubectl apply -f https://docs.projectcalico.org/v3.12/manifests/calico.yaml

# You have a cluster that was setup via load balancer
# copy kubeconfig file from one of the masters and run kubectl get nodes
  mkdir -p $HOME/.kube || true
  rm -f config.txt
  vagrant ssh-config > config.txt
  scp -F config.txt master1:/home/vagrant/.kube/config $HOME/.kube/config
fi
sleep 30
kubectl get nodes -owide
