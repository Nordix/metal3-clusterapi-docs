#!/bin/bash

sudo yum update -y

# Install docker
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce
sudo systemctl enable docker
sudo systemctl start docker
sudo systemctl status docker

# add user to docker group | not effective immediately
sudo usermod -aG docker vagrant #or any user you have

# start loadbalancer container
sudo docker stop lb-server 
sudo docker rm   lb-server 
sudo docker run --name proxy \
    --name lb-server \
    -v /home/vagrant/nginx.conf:/etc/nginx/nginx.conf:ro \
    -p 6443:6443 \
    -d nginx
