#!/bin/bash

rm -f nginx.conf
cp nginx.conf-1.template nginx.conf

# multiple interfaces, pick the second one '-m2'
M1_IP=$(vagrant ssh master1 -- hostname -I | tr ' ' '\n' | grep -m2 1 | tail -n1)
M2_IP=$(vagrant ssh master2 -- hostname -I | tr ' ' '\n' | grep -m3 1 | tail -n1)
M3_IP=$(vagrant ssh master3 -- hostname -I | tr ' ' '\n' | grep -m3 1 | tail -n1)

sed -i 's/M1_IP/'"$M1_IP"'/g' nginx.conf
sed -i 's/M2_IP/'"$M2_IP"'/g' nginx.conf
sed -i 's/M3_IP/'"$M3_IP"'/g' nginx.conf

vagrant ssh loadbalancer -- rm -rf nginx.conf || true

# upload modified nginx.conf file to loadbalancer
vagrant upload nginx.conf loadbalancer

# upload script that starts nginx container on loadbalancer
vagrant upload start.lb.sh loadbalancer

# start lb
vagrant ssh loadbalancer -- chmod 700 start.lb.sh
vagrant ssh loadbalancer -- ./start.lb.sh

