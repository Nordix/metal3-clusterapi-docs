* **Add/replace nodes to an existing cluster**
  * additional resource need, no capacity impact
  * if additional resources not available, scale-in scale-out needed, capacity impact 
  * https://kubernetes.io/docs/setup/release/version-skew-policy/#supported-version-skew
  * kubeadm upgrade is not used in this case
  * should be supported between Kubernetes minor versions, e.g 1.16 to 1.17
  * Note! etcd timeouts have caused issues during join, retry might help

* setup a running cluster (4 masters and 2 workers, masterXX and worker2 are 1.17.0 and others 1.16.3)

```sh
./setup_and_run-XX.sh    
```

* check cluster content and component versions

```sh
kubectl get nodes -owide

kubeadm version
kubelet --version
kubectl version
```

* the cluster leader might be re-elected

```sh
kubectl describe endpoints kube-scheduler -n kube-system
```
