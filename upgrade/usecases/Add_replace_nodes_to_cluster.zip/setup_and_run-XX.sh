#!/bin/bash

vagrant up
echo "------------------"
echo "Setup Loadbalancer"
echo "------------------"
./setup_lb-1.sh

echo "-------------------------"
echo "Run kudeadm init and join"
echo "-------------------------"
./run_me_ug.sh 1.16

echo "-------------------------"
echo "Run kudeadm masterXX and worker2 join"
echo "-------------------------"
vagrant up masterXX
vagrant up worker2
./setup_lb-XX.sh
./run_me_ug.sh 1.17
