* **upgrade with one extra node (or several extra nodes)**
  * additional resource need, no capacity impact
  * join node with new version (kubeadm join)
    * workers with new k8s version can join the cluster but the workers will stay in 'NotReady' state until
      any control-plane node is upgraded to the new k8s version 
  * remove the old node from the cluster (kubeadm reset -f)


vagrant up
./setup_and_run-1.sh
vagrant up worker2
./run_me_ug.sh 1.17

* upgrade one control-plane node, master3
https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-upgrade/

 vagrant ssh master3 -- yum list --showduplicates kubeadm --disableexcludes=kubernetes
 vagrant ssh master3 -- sudo yum install -y kubeadm-1.17.0-0 --disableexcludes=kubernetes
 vagrant ssh master3 -- sudo kubeadm upgrade plan
 vagrant ssh master3 -- sudo kubeadm upgrade apply v1.17.0
 vagrant ssh master3 -- sudo yum install -y kubelet-1.17.0-0 kubectl-1.17.0-0 --disableexcludes=kubernetes
 vagrant ssh master3 -- sudo systemctl restart kubelet
 vagrant ssh master3 -- sudo systemctl daemon-reload


* test upgrade and join of nodes, e.g master3 and worker2
* remove master3 from cluster and join back

vagrant ssh master3 -- sudo kubeadm reset -f

* starting point
kubectl get nodes -owide
NAME      STATUS     ROLES    AGE   VERSION
master1   Ready      master   40m   v1.16.3
master2   Ready      master   39m   v1.16.3 
master3   NotReady   master   37m   v1.17.0 
worker1   Ready      <none>   37m   v1.16.3
worker2   NotReady   <none>   36m   v1.17.0

vagrant ssh master1 -- kubeadm token generate
l3anqt.hz7jxva2cmrh6jkh

vagrant ssh master1 -- sudo kubeadm token create l3anqt.hz7jxva2cmrh6jkh --print-join-command
kubeadm join 172.28.128.90:6443 --token l3anqt.hz7jxva2cmrh6jkh     --discovery-token-ca-cert-hash sha256:ccc04e8c5db7ec1e558a60fc7e52d531a0d9fef2e7d14db7ffc24941db65ea21 

vagrant ssh master1 -- cat /home/vagrant/kubeadm-config.yaml | grep certificateKey | cut -d ':' -f2  | awk '{$1=$1;print}'
94a9e417f846b0833dead841b02beba03763bc328e24589925273ca410041f87

vagrant ssh master3 -- sudo kubeadm join 172.28.128.90:6443 --token l3anqt.hz7jxva2cmrh6jkh --discovery-token-ca-cert-hash sha256:ccc04e8c5db7ec1e558a60fc7e52d531a0d9fef2e7d14db7ffc24941db65ea21 --control-plane --certificate-key 94a9e417f846b0833dead841b02beba03763bc328e24589925273ca410041f87

* final cluster status
kubectl get nodes -owide
NAME      STATUS   ROLES    AGE   VERSION
master1   Ready    master   42m   v1.16.3
master2   Ready    master   40m   v1.16.3
master3   Ready    master   38m   v1.17.0
worker1   Ready    <none>   38m   v1.16.3
worker2   Ready    <none>   37m   v1.17.0
